class Ex4_1 {
	public static void main(String args[]) {
		int score = 80;

		if (score > 60) {
			System.out.println("�հ��Դϴ�.");
		}
	}
}