class Ex2_6 {
   public static void main(String args[]) {
		int 	 x = 100;
		double pi = 3.14;
		char 	 ch = 'a';
		String str = "abc";

		System.out.println(x); 
		System.out.println(pi); 
		System.out.println(ch);
		System.out.println(str);
	}
}